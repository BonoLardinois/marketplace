from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("auction/<str:title>", views.listing_page, name="listing"),
    path("create", views.create, name="create"),
    path("delete", views.delete, name="delete"),
    path("auction/<str:title>/bid", views.bid, name="bid_item"),
    path("auction/<str:title>/comment", views.comment, name="comment"),
    path("auction/<str:title>/add_watchlist",views.add_watchlist, name="add_watchlist"),
    path("watchlist", views.watchlist, name="watchlist"),
    path("delete_watchlist", views.delete_watchlist, name="delete_watchlist"),
    path("my_listings", views.my_listings, name="my_listings"),
    path("auction/<str:title>/edit", views.edit, name="edit"),
    path("auction/<str:title>/close_bidding", views.close_bidding, name="close_bidding"),
    path("categories", views.categories, name="categories"),
    path("categories/<str:category>", views.category, name="category")
]
