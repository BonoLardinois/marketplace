from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class User(AbstractUser):
    pass

class Listings(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=64)
    description = models.CharField(max_length=220)
    time = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete = models.CASCADE, related_name = "owner")
    price = models.DecimalField(max_digits= 8, decimal_places=2)
    image = models.URLField(blank=True)
    bid_closed = models.BooleanField(default=False)
    category = models.CharField(max_length=64)


    def __str__(self):
        return f"{self.title}"

class Bid(models.Model):
    listing = models.ForeignKey(Listings, on_delete=models.CASCADE, related_name="bids")
    price = models.DecimalField(max_digits= 8, decimal_places=2)
    user = models.ForeignKey(User, on_delete = models.CASCADE, related_name = "bidder")
    time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user} bid {self.price} on {self.listing}"

class Comment(models.Model):
    listing= models.ForeignKey(Listings, on_delete=models.CASCADE, related_name="comment")
    comment = models.CharField(max_length=220)
    user = models.ForeignKey(User, on_delete = models.CASCADE, related_name = "commenter")
    time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user} commented on {self.listing}"

class Watchlist(models.Model):
    listing= models.ForeignKey(Listings, on_delete=models.CASCADE, related_name="watch_listing")
    user = models.ForeignKey(User, on_delete = models.CASCADE, related_name = "watch_user")

class Winner(models.Model):
    listing = models.ForeignKey(Listings, on_delete=models.CASCADE, related_name="listing_won")
    user = models.ForeignKey(User, on_delete = models.CASCADE, related_name = "bid_winner")
    bid = models.ForeignKey(Bid, on_delete = models.CASCADE, related_name = "highest_bid")




