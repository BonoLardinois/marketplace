from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.urls import reverse
from .models import Listings, Bid, Comment, Watchlist, Winner
from django import forms
from django.contrib.auth.decorators import login_required
from django.db.models import Max

from .models import User


def index(request):
    listings = Listings.objects.all()
    active_listings = list()
    inactive_listings = list()
    for listing in listings:
        top_bid = Bid.objects.filter(listing = listing).first()
        if listing.bid_closed == False:
            active_listings.append(listing)
        else:
            inactive_listings.append(listing)   

    return render(request, "auctions/index.html", {
        "listings": Listings.objects.all(),
        "active_listings": active_listings,
        "inactive_listings": inactive_listings,
        "top_bid": top_bid
    })


def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "auctions/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")


def listing_page(request, title):
    user =  User.objects.get(username=request.user)
    listing = Listings.objects.get(title=title) 
    bids = Bid.objects.filter(listing = listing).order_by('-price')[:5]
    comments= Comment.objects.filter(listing=listing).order_by('-time')
    top_bid = Bid.objects.filter(listing = listing).first()
    winner = Winner.objects.filter(listing = listing)
    return render(request, "auctions/listing.html", {
        "listing": listing, 
        "bids": bids,
        "comments": comments, 
        "owner": listing.user == user,
        "top_bid": top_bid,
        "winner": winner
    })

@login_required
def create(request):
    
    # creeren van nieuwe pagina
    if request.method == "POST":
        title = request.POST["title"]
        
        # als titel al bestaat dan komt er een error pargina
        if Listings.objects.filter(title = title):
            return render(request, "auctions/error.html", {
                "message": "Listing with this title already exits"
            })
        
        description = request.POST["description"]
        price = request.POST["price"]
        image = request.POST["image"]
        category = request.POST["category"]
        user =  User.objects.get(username=request.user)
        listing = Listings(title = title, description = description, user = user, price = price, image = image, category = category)
        listing.save()
        
        # na opslaan ga je terug naar de index pagina
        return redirect('listing', title = title)

    return render(request, "auctions/create.html")

@login_required
def delete(request):
    
    # gebruiker kan alleen zijn eigen geplaatste listings verwijderen
    user = User.objects.get(username=request.user)
    if request.method == "POST":
        title = request.POST.get('deleting')
        listing = Listings.objects.get(title = title)
        listing.delete()
        return render(request, "auctions/delete_listing.html",{
        "listings": Listings.objects.filter(user = user), 
        "title": title,
        "message": "Succesfull deleted!"
        })

    return render(request, "auctions/delete_listing.html",{
        "listings": Listings.objects.filter(user = user)
    })

@login_required
def bid(request, title):
    listing = Listings.objects.get(title = title) 
    bids = Bid.objects.filter(listing = listing).order_by('-price')[:1]
    if request.method == "POST":
        listing = Listings.objects.get(title = title)
        price = request.POST["bid"]
        
        # als er al op de listing geboden is word het hoogste bod getoond
        if len(Bid.objects.filter(listing = listing)) >= 1:
            top_bid = Bid.objects.filter(listing = listing).first()
            top_bid_price = top_bid.price
            if float(price) <= float(top_bid_price):
                return render(request, "auctions/bid.html" , {
                "listing": listing,
                "bids": bids,
                "message": "Your Bid should be higher than the Current one."
                })
            
        # gebruiker moet hoger bieden dan hoogste bod anders komt er een error
        else:
            if float(price) <= float(listing.price):
                return render(request, "auctions/bid.html" , {
                "listing": listing,
                "bids": bids,
                "message": "Your Bid should be higher than the Current one."
                })

        # bod opslaan
        user =  User.objects.get(username=request.user)
        bid = Bid(listing = listing, price= price, user= user)
        bid.save()

        # gebruiker gaat terug naar listing pagina
        return redirect('listing', title=title)

    return render(request, "auctions/bid.html" , {
    "listing": listing,
    "bids": bids
    })

@login_required
def comment(request, title):
    if request.method == "POST":
        
        # comment van grbuiker opslaan bij de juiste listing
        listing = Listings.objects.get(title=title)
        comment = request.POST["comment_field"]
        user = User.objects.get(username=request.user)
        comment = Comment(listing= listing, comment = comment, user = user)
        comment.save()
        return redirect('listing', title= title)

    listing = Listings.objects.get(title=title) 
    return render(request, "auctions/comment.html", {
        "listing": listing, 
    })

@login_required
def add_watchlist(request, title):
    if request.method == "POST":
        
        # item opslaan en watchlist en listing pagina returnen
        user = User.objects.get(username = request.user)
        listing = Listings.objects.get(title = title)
        if Watchlist.objects.filter(listing = listing, user=user):
            return redirect('listing', title = title)

        add = Watchlist(listing = listing, user = user)
        add.save()
        return redirect('listing', title = title)

@login_required
def watchlist(request):
    
    # watchlist pagina van specifieke gebruiker tonen
    user = User.objects.get(username = request.user)
    items = Watchlist.objects.filter(user = user)
    return render(request, "auctions/watchlist.html", {
        "user": user,
        "items": items
    })

@login_required
def delete_watchlist(request):
    user = User.objects.get(username = request.user)
    items = Watchlist.objects.filter(user = user)
    if request.method == "POST":
        
        # listing van watchlist afhalen
        title = request.POST.get('delete_item')
        listing = Listings.objects.get(title = title)
        listing.delete()
        return render(request, "auctions/delete_watchlist.html", {
        "user": user,
        "items": items,
        "message": "Item deleted"
        })

    return render(request, "auctions/delete_watchlist.html", {
        "user": user,
        "items": items
    })

@login_required
def my_listings(request):
    
    # mijn listings pagina tonen
    user = User.objects.get(username=request.user)
    bids = Bid.objects.filter(user = user)[:5]
    listing = Listings.objects.filter(user=user)
    winner = Winner.objects.all()[:5]
    return render(request, "auctions/my_listings.html", {
        "bids": bids,
        "listings": listing,
        "winner": winner
    })

@login_required
def edit(request,title):
    listing = Listings.objects.get(title=title)
    if request.method == "POST":
        
        # Velden van listing updaten met door gebruiker ingevoerde gegevens worden geupdate           
        listing.title = request.POST['title']
        listing.description = request.POST['text']
        listing.image = request.POST['image']
        listing.price = request.POST['price']
        listing.category = request.POST['category']
        listing.save()
        
        return redirect('listing', title = title)
    
    return render(request, "auctions/edit.html", {
        "listing": listing
    })

@login_required
def close_bidding(request, title):
    if request.method == "POST":
        listing = Listings.objects.get(title=title)
        
        # als er nog niet op de listing is geboden kan de bieding niet worden gesloten
        if len(Bid.objects.filter(listing = listing)) == 0:
            return render(request, "auctions/error.html", {
                "message": "Can't close no biddings yet!"
            })
        
        # updaten van status van bieding
        listing.bid_closed = True
        listing.save()

        # opslaan wie er de hoogste bieding heeft
        user =  User.objects.get(username = request.user)
        bid = Bid.objects.filter(listing = listing).first()
        highest_bid = Winner(listing = listing, user = user, bid = bid)
        highest_bid.save()

        return redirect('listing', title = title)

def categories(request):
    
    # elke category mag maar 1 keer voorkomen op de pagina
    categories = set()
    listings = Listings.objects.all()
    for listing in listings:
        if not listing.category:
            continue
        else:
            categories.add(listing.category)

    return render(request, "auctions/categories.html", {
        "categories": categories
    })

def category(request, category):
    
    # pagina voor listings met dezelfde categorie 
    listings = Listings.objects.filter(category = category)
    return render(request, "auctions/category.html", {
        "listings": listings,
        "category": category
    })
