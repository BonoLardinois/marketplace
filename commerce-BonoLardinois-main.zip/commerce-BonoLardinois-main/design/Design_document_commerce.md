Design document of Commerce Assignment
![Commerce design document](https://user-images.githubusercontent.com/78788799/117450121-1f6e7600-af41-11eb-9c72-f6bdf9cfee5d.jpg)
