Overview of which models have been used for each page

Index page:
- Listings model      --> to display all the listings
- Bid model           --> to display the highest bidding

Create a new listing:
- Listings model      --> to save the new listing to 
- User model          --> to save the creator of the listing

Delete a listing page:
- User model           --> to show only the listing which the user had created
- Listings model       --> filterd on title to only deleted that specific title

Bidding page:
- User                --> to save to bidding with the User
- Bid model           --> to save the bidding
- Listings model      --> filtered on the listing 

Comment page:
- Listings model      --> filtered on the listing
- Comment model       --> to save the comment
- User model          --> to get the user

To add something to watchlist:
- User model          --> to get the user
- Listings model      --> filterd by title
- Watchlist model     --> filtered by user

My listing page:
- Listings model     --> filtered by title
- Bid model          --> filtered by user
- Winner model       --> filtered by user

Close bidding:
- Listing model     --> to get the specific listing
- Bid model         --> to see if there has been an bidding on the listing
- Winner model      --> Save the highest bid 

Categories page:
- Listings model    --> to get all categories of the listings

Category page:
- Listings model    --> filtered on category
