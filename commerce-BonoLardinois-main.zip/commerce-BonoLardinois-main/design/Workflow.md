Making a new listing:
1. click link: create new listing
2. fill out the form and click save
3. listing has been made

Delete a listing:
1. clink link: delete listing
2. select a listing
3. click delete
4. listing has been deleted

My listing page:
See what biddings you have won, biddings you have made and listings you have made

Watchlist:
See what items are on your watchlist

Listing page:
- make a bidding on that listing
- make a comment on that bidding
-------------- if you are the owner --------------
you can edit the page of you can close the bidding

Categories page:
- See all the categories of the listings
- When you click a category you will be taken to the page of that category with all the listings of that category
