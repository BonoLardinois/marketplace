This is an overview of the models which have been made to create the auction website

![Models Commerce](https://user-images.githubusercontent.com/78788799/117449949-dcac9e00-af40-11eb-82b5-3d5df1ab61b4.jpg)
