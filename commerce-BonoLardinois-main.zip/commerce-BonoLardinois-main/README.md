
# Auctions webpage

Webpage for auctioning of things, you can make an account, create a listing, bid on a listing etc
A listing page shows: an image of that listing, biddings on that listing and a description. 

Example of Index page with listings:
![Schermafbeelding 2021-05-07 om 13 49 56](https://user-images.githubusercontent.com/78788799/117451157-71fc6200-af42-11eb-8008-148f61c2cee0.png)


## Getting Started

Steps to open this project:

1. download with: git clone https://github.com/uva-webapps/commerce-BonoLardinois.git (in terminal)
2. open in text editor
2. run the site with python manage.py runserver
3. the site opens in the prefered browser

See the map design for a overview of the design and implementation of models and overall design of the webpages:
https://github.com/uva-webapps/commerce-BonoLardinois/tree/main/design
